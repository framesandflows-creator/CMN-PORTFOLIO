---
name: Executive Portfolio System
colors:
  surface: '#14121b'
  surface-dim: '#14121b'
  surface-bright: '#3a3842'
  surface-container-lowest: '#0e0d16'
  surface-container-low: '#1c1a24'
  surface-container: '#201e28'
  surface-container-high: '#2b2932'
  surface-container-highest: '#35333e'
  on-surface: '#e5e0ee'
  on-surface-variant: '#c9c4d8'
  inverse-surface: '#e5e0ee'
  inverse-on-surface: '#312f39'
  outline: '#928ea1'
  outline-variant: '#484555'
  surface-tint: '#c9bfff'
  primary: '#c9bfff'
  on-primary: '#2e009c'
  primary-container: '#917eff'
  on-primary-container: '#28008a'
  inverse-primary: '#5d3fe0'
  secondary: '#8fd8ff'
  on-secondary: '#003548'
  secondary-container: '#00c1fd'
  on-secondary-container: '#004b65'
  tertiary: '#e1c297'
  on-tertiary: '#402d0e'
  tertiary-container: '#a88c65'
  on-tertiary-container: '#382608'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5deff'
  primary-fixed-dim: '#c9bfff'
  on-primary-fixed: '#1a0063'
  on-primary-fixed-variant: '#441cc8'
  secondary-fixed: '#c2e8ff'
  secondary-fixed-dim: '#75d1ff'
  on-secondary-fixed: '#001e2b'
  on-secondary-fixed-variant: '#004d67'
  tertiary-fixed: '#fedeb1'
  tertiary-fixed-dim: '#e1c297'
  on-tertiary-fixed: '#281800'
  on-tertiary-fixed-variant: '#584322'
  background: '#14121b'
  on-background: '#e5e0ee'
  surface-variant: '#35333e'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 80px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-page: 64px
  section-gap: 160px
---

## Brand & Style
This design system embodies the "Apple Executive" aesthetic: a high-fidelity, dark-mode-first interface that prioritizes focus through deep contrast and atmospheric depth. The brand personality is one of quiet confidence, utilizing vast negative space and microscopic precision to signal premium quality.

The visual style is a hybrid of **VisionOS-inspired Glassmorphism** and **Cinematic Minimalism**. It relies on high-index backdrop blurs and subtle "liquid" transitions that make the UI feel alive yet anchored. Surface layers are treated as physical sheets of smoked glass, creating a multi-dimensional workspace where content floats with purpose.

## Colors
The palette is rooted in an "Infinite Black" (#050505) foundation to maximize OLED contrast and depth. 

- **Primary (Royal Purple):** Used sparingly for high-level brand moments and primary calls to action.
- **Secondary (Electric Blue):** Reserved for interactive feedback, links, and system-status indicators.
- **Tertiary (Champagne Gold):** An accent for luxury signifiers, such as "Pro" badges or achievement highlights.
- **Surface Strategy:** Layers are built using #111111 (Charcoal) for solid containers and a custom glass recipe (8% white opacity) for floating navigation and overlays.

## Typography
While SF Pro Display is the primary inspiration for its authoritative air, **Inter** is utilized as the core driver for its exceptional legibility on digital screens and modern character. 

The typographic hierarchy is exaggerated. Display headings are massive and tightly tracked to create a "editorial" feel, while body text remains breathable with generous line heights. Use `label-caps` for eyebrows and small metadata to maintain a structured, technical aesthetic. Every character should feel intentional, with zero unnecessary ornamentation.

## Layout & Spacing
This design system employs a **Fixed Grid Strategy** with 12 columns, centered on the viewport. However, the spacing philosophy is defined by "The Breath"—wide vertical gaps (160px+) between major sections to prevent information density from feeling overwhelming.

Internal component spacing follows a strict 8px linear scale. Use generous padding within cards (min 32px) to ensure content never feels cramped. Hero sections should utilize 100vh height where possible to immerse the user in the "Atmospheric" background blurs.

## Elevation & Depth
Depth is not communicated through traditional drop shadows, but through **Backdrop Blur (Vibrancy)** and **Inner Glows**.

1.  **Level 0 (Base):** #050505 background with an animated mesh gradient (Purple/Blue) at 10% opacity in the background.
2.  **Level 1 (Cards):** #111111 with a 1px solid border at 10% white opacity.
3.  **Level 2 (Glass):** `rgba(255,255,255,0.08)` with a `backdrop-filter: blur(40px)`. This level is used for navigation bars and floating modals.
4.  **Interaction:** When hovered, elements should "lift" via a subtle scale increase (1.02x) and a soft, wide outer glow (40px blur) tinted with the Primary color at 15% opacity.

## Shapes
The shape language follows a "Squircle" philosophy. While the base roundedness is set to `2` (0.5rem), large-scale containers like cards and hero images must use `rounded-xl` (1.5rem) to achieve the soft, organic feel of high-end hardware. 

Interactive elements like buttons and input fields should strictly adhere to the `rounded-lg` (1rem) standard, ensuring a consistent touch-target expectation. Avoid sharp corners entirely to maintain the approachable, premium executive tone.

## Components
- **High-Contrast Cards:** Build with a #111111 fill and a subtle 1px top-down linear gradient border (White to Transparent) to simulate "rim lighting."
- **Primary Buttons:** Solid white fill with black text. On hover, transition to a Royal Purple glow effect. Use a "liquid" hover animation where the width expands slightly.
- **Glass Navigation:** A fixed-position pill centered at the top or bottom. Use the glassmorphic recipe with `saturate(180%)` to make underlying colors pop.
- **Input Fields:** Minimalist underlines or subtle #111111 fills. Focus states should trigger a 1px Electric Blue glow and a label lift animation.
- **Immersive Hero:** Combines `display-xl` typography with a background "liquid motion" video or WebGL shader that reacts to mouse movement.
- **Interactive Chips:** Small, pill-shaped elements with a 1px Champagne Gold border for highlighting specific categories or tags.